class Persona {
    constructor(nombre, edad) {
      this.nombre = nombre;
      this.edad = edad;
    }
    // Métodos
    obtDetalles() {
        alert('¡Hola! soy ' + this.nombre + 'Y tengo' + this.edad);
    }
  }


  class Estudiante extends Persona{
    constructor(nombre, edad, calificacion) {
        super(nombre, edad);
        this.calificacion = calificacion;
    }
    // Métodos
    obtDetalles() {
        alert('¡Hola! soy ' + this.nombre + 'Y tengo' + this.edad + 'Mi calificacion' + this.calificacion);
    }
  }

  class Profesor extends Persona{
    constructor(nombre, edad, asignatura, nivel) {
      super(nombre, edad);
      this.asignatura = JS;
      this.nivel = básico;
    }
    // Métodos
    obtDetalles() {
        alert('¡Hola! soy ' + this.nombre + 'Y tengo' + this.edad + 'Asignatura' + this.asignatura+ 'Nivel' + this.nivel);
    }
  }

  class Grupo{
    constructor(){
      this.estudiantes = [];
    }
    
    agregarEstudiante(estudiante){
        this.estudiantes.push(estudiante);
    }
  }
    

  const Alex = new Persona("Alejandro",35);
  Alex.obtDetalles();

  const grupo1 = new Grupo();
  grupo1.agregarEstudiante({nombre: "Diego", edad: 25});
  grupo1.agregarEstudiante({nombre: "Lorena", edad: 32});
  grupo1.agregarEstudiante({nombre: "Arturo", edad: 18});
  grupo1.agregarEstudiante({nombre: "Valeria", edad: 29});
  grupo1.agregarEstudiante({nombre: "Erick", edad: 23});
  grupo1.agregarEstudiante({nombre: "Alejandro", edad: 21});

  const Profesor1 = new Profesor("Ruth", 54);