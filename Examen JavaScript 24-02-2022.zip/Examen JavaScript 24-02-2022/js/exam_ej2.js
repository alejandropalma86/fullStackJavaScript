let numero;
let factorial = 1;
let flag;
let aux;

do {
    numero=prompt('Capture un número para calcular su Factorial: ');
    if (isNaN(numero)) {
        alert("El valor capturado no es un número");
    }  else if(numero % 1 !=0){
            alert("Capture un número entero");
    }   else if(numero==0 || numero>100){
        alert("Capture un número entre 1 y 100");
    } else{
        flag=1;
    }
      
} while (flag!=1);

for(aux=1; aux<=numero; aux++){
    factorial*=aux;
}
alert("El factorial es igual a: "+ factorial);