let numero;
let flag;

do {
    numero=prompt('Capture un número para determinar si es Par o Impar: ');
    if (isNaN(numero)) {
        alert("El valor capturado no es un número");
    }  else if(numero % 1 !=0){
            alert("Capture un número entero");
    }   else if(numero==0 || numero>100){
        alert("Capture un número entre 1 y 100");
    } else{
        flag=1;
    }
      
} while (flag!=1);

function parImpar(num){
    let resultado;
    if (num%2==0) {
        resultado="PAR";
     } else {
        resultado="IMPAR";
     }
     return resultado;
}


let consulta = parImpar(numero);
alert("El número es: "+ consulta);
