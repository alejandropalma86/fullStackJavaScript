let frase=prompt('Capture una frase para validar si es Palindromo: ');
 
 function palindromo(frase){
   frase=frase.toLowerCase().replace(/\s/g,"");
   fraseReversa=frase.split("").reverse().toString();
   for (let i = 0; i < ((fraseReversa.length)-1); i++) {
     fraseReversa=fraseReversa.replace(",","");
   };
   if(frase==fraseReversa){
     resultado="es Palindromo";
   }
   else{
     resultado="no es Palindromo";
   }
   alert("La frase "+resultado);
 }
 
 palindromo(frase);
